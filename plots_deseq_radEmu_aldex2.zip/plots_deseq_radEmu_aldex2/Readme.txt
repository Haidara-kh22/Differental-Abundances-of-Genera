the number of taxa obtained from tools to visualize in the genus classification : 25
the number of taxa obtained from tools to visualize in the species classification : 50
except for dataset (3,4,5,9) there number is mentioned in the notes.txt file
